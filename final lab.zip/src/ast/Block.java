package ast;
import java.util.List;
import java.util.ArrayList;

/**
 * Class that stores the components of a block.
 *
 * Block               - constructor
 * getStatements       - gets a list of all the statements
 *
 * @author Hilari Fan
 * @version 3/25/20
 *
 * Usage:
 * Component of the abstract syntax tree created in parsing and used in executing / evaluating
 */
public class Block extends Statement
{
    private List<Statement> stmts;

    /**
     * constructor of the Block
     *
     * @param stmts a list of all the statements
     */
    public Block(List<Statement> stmts)
    {
        this.stmts = new ArrayList<Statement>();
        for (int i = 0; i < stmts.size(); i++)
        {
            this.stmts.add(stmts.get(i));
        }
    }

    /**
     * gets the list of statements
     *
     * @precondition none
     * @postcondition none
     * @return the list
     */
    public List<Statement> getStatements()
    {
        return stmts;
    }
}
