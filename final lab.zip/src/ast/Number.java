package ast;

/**
 * Class that stores the components of a number.
 *
 * Number             - constructor
 * getInt             - gets the int value of the number
 *
 * @author Hilari Fan
 * @version 3/25/20
 *
 * Usage:
 * Component of the abstract syntax tree created in parsing and used in executing / evaluating
 */
public class Number extends Expression
{
    private int value;

    /**
     * Constructor of the Number
     *
     * @param value the int of the number
     */
    public Number(int value)
    {
        this.value = value;
    }

    /**
     * gets the int value of the number
     *
     * @precondition none
     * @postcondition none
     * @return the int
     */
    public int getInt()
    {
        return value;
    }
}
