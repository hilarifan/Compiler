package ast;

/**
 * Class that stores the components of an if statement.
 *
 * If                 - constructor
 * getCondition       - gets the condition of the if statement
 * getStatement       - gets the statement of the if statement
 *
 * @author Hilari Fan
 * @version 3/25/20
 *
 * Usage:
 * Component of the abstract syntax tree created in parsing and used in executing / evaluating
 */
public class If extends Statement
{
    private Condition cond;
    private Statement stmt;

    /**
     * constructor of the If statement
     * @param cond condition (if __)
     * @param stmt statement (then __)
     */
    public If(Condition cond, Statement stmt)
    {
        this.cond = cond;
        this.stmt = stmt;
    }

    /**
     * gets the condition of the if statement
     *
     * @precondition none
     * @postcondition none
     * @return the condition
     */
    public Condition getCondition()
    {
        return cond;
    }

    /**
     * gets the statement of the if statement
     *
     * @precondition none
     * @postcondition none
     * @return the statement
     */
    public Statement getStatement()
    {
        return stmt;
    }
}
