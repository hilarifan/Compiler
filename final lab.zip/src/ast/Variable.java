package ast;

/**
 * Class that stores the components of a variable.
 *
 * Variable           - constructor
 * getName            - gets the name of the variable
 *
 * @author Hilari Fan
 * @version 3/25/20
 *
 * Usage:
 * Component of the abstract syntax tree created in parsing and used in executing / evaluating
 */
public class Variable extends Expression
{
    private String name;

    /**
     * Constructor of the Variable
     *
     * @param name of the variable
     */
    public Variable(String name)
    {
        this.name = name;
    }

    /**
     * gets the variable name
     *
     * @precondition none
     * @postcondition none
     * @return the name
     */
    public String getName()
    {
        return name;
    }
}
