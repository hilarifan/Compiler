package ast;

/**
 * Class that stores the components of a while loop.
 *
 * While              - constructor
 * getCondition       - gets the condition of the while loop
 * getStatement       - gets the statement of the while loop
 *
 * @author Hilari Fan
 * @version 3/25/20
 *
 * Usage:
 * Component of the abstract syntax tree created in parsing and used in executing / evaluating
 */
public class While extends Statement
{
    private Condition cond;
    private Statement stmt;

    /**
     * constructor of the While loop
     * @param cond condition (while __)
     * @param stmt statement (do __)
     */
    public While(Condition cond, Statement stmt)
    {
        this.cond = cond;
        this.stmt = stmt;
    }

    /**
     * gets the condition of the while loop
     *
     * @precondition none
     * @postcondition none
     * @return the condition
     */
    public Condition getCondition()
    {
        return cond;
    }

    /**
     * gets the statement of the while loop
     *
     * @precondition none
     * @postcondition none
     * @return the statement
     */
    public Statement getStatement()
    {
        return stmt;
    }
}
