package ast;
import java.util.ArrayList;
import emitter.Emitter;

/**
 * Class that stores the components of a program after the procedures.
 *
 * Program             - constructor
 * getStatement        - gets the statement of the program
 * getVariables        - gets the list of global variable names of the program
 * getDeclarations     - gets the list of procedure declarations of the program
 *
 * @author Hilari Fan
 * @version 4/7/20
 *
 * Usage:
 * Root of the abstract syntax tree created in parsing and used in executing / evaluating
 */
public class Program
{
    private Statement stmt;
    private ArrayList<ProcedureDeclaration> dec;
    private ArrayList<Variable> var;

    /**
     * constructor of the Program
     *
     * @param var the list that contains all the global variable names
     * @param dec the list that contains all the procedure declarations
     * @param stmt the statement following the arbitrary number of procedures
     */
    public Program(ArrayList<Variable> var, ArrayList<ProcedureDeclaration> dec, Statement stmt)
    {
        this.stmt = stmt;
        this.var = new ArrayList<Variable>();
        this.var.addAll(var);
        this.dec = new ArrayList<ProcedureDeclaration>();
        this.dec.addAll(dec);
    }

    /**
     * gets the statement
     *
     * @precondition none
     * @postcondition none
     * @return statement of the program
     */
    public Statement getStatement()
    {
        return stmt;
    }

    /**
     * gets the list of the global variable names
     *
     * @precondition none
     * @postcondition none
     * @return arraylist of the variable declarations
     */
    public ArrayList<Variable> getVariables()
    {
        return var;
    }

    /**
     * gets the list of the procedure declarations
     *
     * @precondition none
     * @postcondition none
     * @return arraylist of the procedure declarations
     */
    public ArrayList<ProcedureDeclaration> getDeclarations()
    {
        return dec;
    }
}
