package ast;

/**
 * Class that stores the components of a binary operation.
 *
 * BinOp              - constructor
 * getOperator        - gets the operator
 * getExpression1     - gets the 1st expression of a binary operation
 * getExpression2     - gets the 2nd expression of a binary operation
 *
 * @author Hilari Fan
 * @version 3/25/20
 *
 * Usage:
 * Component of the abstract syntax tree created in parsing and used in executing / evaluating
 */
public class BinOp extends Expression
{
    private String op;
    private Expression exp1;
    private Expression exp2;

    /**
     * Constructor of the Assignment
     *
     * @param op string of the binary operator
     * @param exp1 one of the expressions
     * @param exp2 the other expression
     */
    public BinOp(String op, Expression exp1, Expression exp2)
    {
        this.op = op;
        this.exp1 = exp1;
        this.exp2 = exp2;
    }

    /**
     * gets the binary operator string
     *
     * @precondition none
     * @postcondition none
     * @return the operator
     */
    public String getOperator()
    {
        return op;
    }

    /**
     * gets the first expression of the binop
     *
     * @precondition none
     * @postcondition none
     * @return the 1st expression
     */
    public Expression getExpression1()
    {
        return exp1;
    }

    /**
     * gets the second expression of the binop
     *
     * @precondition none
     * @postcondition none
     * @return the 2st expression
     */
    public Expression getExpression2()
    {
        return exp2;
    }
}
