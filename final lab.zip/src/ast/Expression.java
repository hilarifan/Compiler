package ast;

/**
 * Abstract class for all expressions (extended by Number, Variable, BinOp, Condition)
 *
 * @author Hilari Fan
 * @version 3/25/20
 */
public abstract class Expression
{
}
