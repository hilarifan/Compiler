package ast;
import java.util.ArrayList;

/**
 * Class that stores the components of a procedure declaration.
 *
 * ProcedureDeclaration       - constructor
 * getName                    - gets the name of the procedure
 * getVariables               - gets the list of local variables in the procedure
 * getStatement               - gets the statement in the procedure
 * getParameters              - gets the parameters of a procedure
 *
 * @author Hilari Fan
 * @version 4/7/20
 *
 * Usage:
 * When the procedure is called for executing / evaluating
 */
public class ProcedureDeclaration extends Statement
{
    private String name;
    private ArrayList<Variable> var;
    private Statement stmt;
    private ArrayList<String> parms;

    /**
     * constructor of the ProcedureDeclaration
     *
     * @param name the name of the procedure
     * @param var the list that contains the local variable names
     * @param stmt the statement of the procedure
     * @param parms the list of parameters of the procedure
     */
    public ProcedureDeclaration(String name, ArrayList<Variable> var,
                                Statement stmt, ArrayList<String> parms)
    {
        this.name = name;
        this.var = new ArrayList<Variable>();
        this.var.addAll(var);
        this.stmt = stmt;
        this.parms = new ArrayList<String>();
        this.parms.addAll(parms);
    }

    /**
     * gets the name of the procedure
     *
     * @precondition none
     * @postcondition none
     * @return the String of the name
     */
    public String getName()
    {
        return name;
    }

    /**
     * gets the list of the local variable names
     *
     * @precondition none
     * @postcondition none
     * @return arraylist of the variable declarations
     */
    public ArrayList<Variable> getVariables()
    {
        return var;
    }

    /**
     * gets the statement, which is the body of the procedure declaration
     *
     * @precondition none
     * @postcondition none
     * @return the statement
     */
    public Statement getStatement()
    {
        return stmt;
    }

    /**
     * gets the list of parameters of the procedure declaration
     *
     * @precondition none
     * @postcondition none
     * @return the list of strings
     */
    public ArrayList<String> getParameters()
    {
        return parms;
    }
}
