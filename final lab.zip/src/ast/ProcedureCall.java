package ast;
import java.util.ArrayList;

/**
 * Class that stores the components of a procedure call.
 *
 * ProcedureCall      - constructor
 * getName            - gets the name of the procedure
 * getArguments       - gets the arguments of the procedure
 *
 * @author Hilari Fan
 * @version 4/7/20
 *
 * Usage:
 * When evaluating the procedure call
 */
public class ProcedureCall extends Expression
{
    private String name;
    private ArrayList<Expression> args;

    /**
     * constructor of the ProcedureCall
     *
     * @param name the name of the procedure
     * @param args the list of the expression for each argument
     */
    public ProcedureCall(String name, ArrayList<Expression> args)
    {
        this.name = name;
        this.args = new ArrayList<Expression>();
        this.args.addAll(args);
    }

    /**
     * gets the name of the procedure
     *
     * @precondition none
     * @postcondition none
     * @return the String of the name
     */
    public String getName()
    {
        return name;
    }

    /**
     * gets the list of arguments of the procedure call
     *
     * @precondition none
     * @postcondition none
     * @return the list of expressions
     */
    public ArrayList<Expression> getArguments()
    {
        return args;
    }
}
