package ast;

/**
 * Class that stores the components of a condition.
 *
 * Condition                - constructor
 * getRelationalOperator    - gets the relational (or boolean AND OR NOT) operator
 * getExpression1           - gets the 1st expression of the relational operation
 * getExpression2           - gets the 2nd expression of the relational operation
 *
 * @author Hilari Fan
 * @version 3/25/20
 *
 * Usage:
 * Component of the abstract syntax tree created in parsing and used in executing / evaluating
 */
public class Condition extends Expression
{
    private String relop;
    private Expression exp1;
    private Expression exp2;

    /**
     * constructor for the Condition
     *
     * @param relop string of the relational (or boolean) operator
     * @param exp1 one of the expressions
     * @param exp2 the other expression
     */
    public Condition(String relop, Expression exp1, Expression exp2)
    {
        this.relop = relop;
        this.exp1 = exp1;
        this.exp2 = exp2;
    }

    /**
     * gets the relational (or boolean) operator string
     *
     * @precondition none
     * @postcondition none
     * @return the operator
     */
    public String getRelationalOperator()
    {
        return relop;
    }

    /**
     * gets the first expression of the relop
     *
     * @precondition none
     * @postcondition none
     * @return the 1st expression
     */
    public Expression getExpression1()
    {
        return exp1;
    }

    /**
     * gets the second expression of the relop
     *
     * @precondition none
     * @postcondition none
     * @return the 2st expression
     */
    public Expression getExpression2()
    {
        return exp2;
    }
}
