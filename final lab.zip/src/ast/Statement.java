package ast;

/**
 * Abstract class for all statements (extended by Writeln, Assignment, Block, If, While)
 *
 * @author Hilari Fan
 * @version 3/25/20
 */
public abstract class Statement
{
}
