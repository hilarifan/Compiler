package ast;

/**
 * Class that stores the components of a writeln statement.
 *
 * Writeln            - constructor
 * getExpression      - gets the expression in the writeln statement
 *
 * @author Hilari Fan
 * @version 3/25/20
 *
 * Usage:
 * Component of the abstract syntax tree created in parsing and used in executing / evaluating
 */
public class Writeln extends Statement
{
    private Expression exp;

    /**
     * Constructor of the Writeln
     * @param exp expression inside writeln(_)
     */
    public Writeln(Expression exp)
    {
        this.exp = exp;
    }

    /**
     * gets the expression in writeln
     *
     * @precondition none
     * @postcondition none
     * @return the expression
     */
    public Expression getExpression()
    {
        return exp;
    }
}
