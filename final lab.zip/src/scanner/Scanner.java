package scanner;

import java.io.*;
import java.io.IOException;
import java.io.FileInputStream;

/**
 * This file builds a scanner that can read input, identify lexemes, and produce a string of tokens.
 *
 * scanner.Scanner        - constructor from a given input stream or string
 * getNextChar            - reads the next character and updates the instances, eof or currentChar
 * hasNext                - checks if there is a next character
 * eat                    - advances the input stream by a character
 *                          if the input matches currentChar
 * isDigit                - checks if a character is a digit
 * isLetter               - checks if a character is a letter
 * isWhiteSpace           - checks if a character is a white space
 * scanNumber             - scans the input and returns the number lexeme if found
 * scanIdentifier         - scans the input and returns the identifier lexeme if found
 * scanOperand            - scans the input and returns the operand lexeme if found
 * nextToken              - identifies and returns the lexeme by scanning the next token
 *                          using the above scan helper methods
 *
 * @author Hilari Fan
 * @version 1/24/20
 *
 * Usage:
 * create a string of tokens according to a set of rules specified in the class by using nextToken
 *
 */
public class Scanner
{
    private BufferedReader in;
    private char currentChar;
    private boolean eof;
    /**
     * scanner.Scanner constructor for construction of a scanner that
     * uses an InputStream object for input.
     * Usage:
     * FileInputStream inStream = new FileInputStream(new File(<file name>)_;
     * scanner.Scanner lex = new scanner.Scanner(inStream);
     * @param inStream the input stream to use
     */
    public Scanner(InputStream inStream)
    {
        in = new BufferedReader(new InputStreamReader(inStream));
        eof = false;
        getNextChar();
    }

    /**
     * scanner.Scanner constructor for constructing a scanner that
     * scans a given input string.  It sets the end-of-file flag an then reads
     * the first character of the input string into the instance field currentChar.
     * Usage: scanner.Scanner lex = new scanner.Scanner(input_string);
     * @param inString the string to scan
     */
    public Scanner(String inString)
    {
        in = new BufferedReader(new StringReader(inString));
        eof = false;
        getNextChar();
    }

    /**
     * sets the currentChar to the next character read from the input stream
     * changes the instance for end of file if it is reached
     *
     * @precondition input stream has a next character
     * @postcondition currentChar updated
     */
    private void getNextChar()
    {
        try
        {
            int inp = this.in.read();

            if (inp == '.' || inp == -1)
            {
                eof = true;
            }
            else
            {
                currentChar = (char)inp;
            }
        }
        catch (IOException var2)
        {
            var2.printStackTrace();
            System.exit(-1);
        }
    }

    /**
     * checks if their is a next character in the input stream
     *
     * @precondition none
     * @postcondition none
     *
     * @return true if there is; otherwise, returns false
     */
    public boolean hasNext()
    {
        return !eof;
    }

    /**
     * takes in a character, compares it to the current character,
     * and advances the input stream by 1 character if they match;
     * otherwise, throws scanner.ScanErrorException
     *
     * @precondition input stream has a next character
     * @postcondition currentChar updated
     *
     * @param expected the character that is expected to match the currentChar
     */
    private void eat(char expected) throws ScanErrorException
    {
        if (expected == currentChar)
        {
            getNextChar();
        }
        else
        {
            throw new ScanErrorException("Illegal character - expected " +
                    expected + " and found " + currentChar);
        }
    }

    /**
     * takes in a character and checks if it is a digit
     *
     * @precondition none (since input can be digit or something else)
     * @postcondition none
     *
     * @param input a character
     * @return true if the input is a digit; otherwise, returns false
     */
    public static boolean isDigit(char input)
    {
        return input >= '0' && input <= '9';
    }

    /**
     * takes in a character and checks if it is a letter
     *
     * @precondition none
     * @postcondition none
     *
     * @param input a character
     * @return true if the input is a letter; otherwise, returns false
     */
    public static boolean isLetter(char input)
    {
        return (input >= 'a' && input <= 'z') || (input >= 'A' && input <= 'Z');
    }

    /**
     * takes in a character and checks if it is a white space
     *
     * @precondition none
     * @postcondition none
     *
     * @param input a character
     * @return true if the input is a white space; otherwise, returns false
     */
    public static boolean isWhiteSpace(char input)
    {
        return input == ' ' || input == '\t' || input == '\r' || input == '\n';
    }

    /**
     * scans the input and creates a lexeme using the regular expression defined as
     * number := digit(digit)*
     *
     * @precondition currentChar is a digit
     * @postcondition currentChar updated
     *
     * @return a String representing a number
     * @throws ScanErrorException if no lexeme is recognized
     */
    private String scanNumber() throws ScanErrorException
    {
        String lexeme = "";

        while (isDigit(currentChar))
        {
            lexeme += currentChar;
            eat(currentChar);
        }

        return lexeme;
    }

    /**
     * scans the input and creates a lexeme using the regular expression defined as
     * identifier := letter(letter | digit)*
     *
     * @precondition currentChar is a letter
     * @postcondition currentChar updated
     *
     * @return a String representing an identifier
     * @throws ScanErrorException if no lexeme is recognized
     */
    private String scanIdentifier() throws ScanErrorException
    {
        String lexeme = "";

        if (isLetter(currentChar))
        {
            while (isDigit(currentChar) || isLetter(currentChar))
            {
                lexeme += currentChar;
                eat(currentChar);
            }
        }

        return lexeme;
    }

    /**
     * scans the input and creates a lexeme using the regular expression defined as
     * operand := ['=''+''-''*''/''%''('')''<''>'';'',''<=''>='':=''<>']
     *
     * @precondition currentChar is an operator
     * @postcondition currentChar updated
     *
     * @return a String representing an operand
     * @throws ScanErrorException if no lexeme is recognized
     */
    private String scanOperand() throws ScanErrorException
    {
        String lexeme = "";

        if (currentChar == '=' || currentChar == '+' || currentChar == '-' || currentChar == '*'
                || currentChar == '/' || currentChar == '%' || currentChar == '('
                || currentChar == ')' || currentChar == '>' || currentChar == '<'
                || currentChar == ':' || currentChar == ';' || currentChar == ',')
        {
            lexeme += currentChar;
            eat(currentChar);
        }

        if (((lexeme.equals("<") || lexeme.equals(">") || lexeme.equals(":")) && currentChar == '=')
                || (lexeme.equals("<") && currentChar == '>'))
        {
            lexeme += currentChar;
            eat(currentChar);
        }

        return lexeme;
    }

    /**
     * skips white spaces and single line comments, examines value of currentChar,
     * scans the next token in the input stream, and creates a lexeme
     * uses the helper methods scanNumber, scanIdentifier, and scanOperand to scan the next token
     *
     * @precondition currentChar represents part of or a lexeme that is defined in this class
     * @postcondition currentChar updated
     *
     * @return a String representing the lexeme found or
     * "END" if the input stream is at the end of file when this method is called
     */
    public String nextToken() throws ScanErrorException
    {
        String token = "";

        while (hasNext() && isWhiteSpace(currentChar))
        {
            eat(currentChar);
        }

        if (hasNext() && currentChar == '/')
        {
            eat(currentChar);

            if (hasNext() && currentChar == '/')
            {
                while (hasNext() && currentChar != '\n')
                {
                    eat(currentChar);
                }

                eat(currentChar); // eats the white space
            }
            else
            {
                token = "/";
            }
        }

        if (!hasNext())
        {
            token = "END";
        }
        else if (token.equals(""))
        {
            if (isDigit(currentChar))
            {
                token = scanNumber();
            }
            else if (isLetter(currentChar))
            {
                token = scanIdentifier();
            }
            else
            {
                token = scanOperand();
            }

            if (token.equals(""))
            {
                throw new ScanErrorException("character is unrecognized");
            }
        }

        return token;
    }

    /**
     * tests the functionality of the scanner using Ms. Datar's ScannerTest files
     * instead of throwing the scanErrorException, skips over the unidentified characters
     * @param args argument
     */
    public static void main(String[] args)
    {
        File file = new File("ScannerTest.txt");
        boolean end = false;

        try
        {
            FileInputStream inStream = new FileInputStream(file);
            Scanner lex = new Scanner(inStream);

            while (!end)
            {
                try
                {
                    while (lex.hasNext())
                    {
                        System.out.println(lex.nextToken());
                    }

                    end = true;
                }
                catch (ScanErrorException e)
                {
                    try
                    {
                        lex.eat(lex.currentChar);
                    }
                    catch (ScanErrorException ex)
                    {
                        ex.printStackTrace();
                    }
                }
            }
        }
        catch (IOException e)
        {
            System.out.println("Exception occurred when trying to open file");
            e.printStackTrace();
        }

    }
}

