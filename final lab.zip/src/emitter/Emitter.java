package emitter;

import java.io.*;
import ast.ProcedureDeclaration;

/**
 * Class that outputs and writes MIPS instructions to a file
 *
 * Emitter                 - constructor for an Emitter
 * emit                    - writes a line of code into the file
 * close                   - closes the file
 * emitPush                - pushes a value onto the stack
 * emitPop                 - pops a value off the stack
 * nextLabelID             - gets number of if statements
 * nextLabelID2            - gets number of while loops
 * setProcedureContext     - remembers the current procedure context
 * clearProcedureContext   - clears the procedure context to null
 * isLocalVariable         - finds whether the variable is local or global
 * getOffset               - gets the offset of a local variable
 *
 * @author Hilari Fan
 * @version 4/27/20
 *
 * Usage:
 * write MIPs program file
 */
public class Emitter
{
    private PrintWriter out;
    private int ifnum;
    private int whilenum;
    private ProcedureDeclaration currentProc;
    private int excessStackHeight;

    /**
     * constructor for an emitter for writing to a new file with a given name
     *
     * @param outputFileName name of file to write into
     */
    public Emitter(String outputFileName)
    {
        try
        {
            out = new PrintWriter(new FileWriter(outputFileName), true);

            ifnum = 0;    // both if and while num 0 since no if or while statements yet
            whilenum = 0;
            currentProc = null;
            excessStackHeight = 0;
        }
        catch(IOException e)
        {
            throw new RuntimeException(e);
        }
    }

    /**
     * prints one line of code to file (with non-labels indented
     *
     * @precondition file valid
     * @postcondition code written to file
     * @param code what to write to the file
     */
    public void emit(String code)
    {
        if (!code.endsWith(":"))
            code = "\t" + code;
        out.println(code);
    }

    /**
     * closes the file and should be called after all calls to emit
     *
     * @precondition file open
     * @postcondition file closed
     */
    public void close()
    {
        out.close();
    }

    /**
     * pushes a value onto the stack and increments the stack pointer by 4 bytes
     *
     * @precondition register has a value
     * @postcondition a value pushed onto stack
     * @param reg the register that contains the value to get pushed onto the stack
     */
    public void emitPush(String reg)
    {
        emit("subu $sp $sp 4   # push a number onto the stack");
        emit("sw " + reg + " ($sp)");

        excessStackHeight++; //NEW
    }

    /**
     * pops a value off the stack and decrements the stack pointer by 4 bytes
     *
     * @precondition value exists in the stack
     * @postcondition value pushed off of stack
     * @param reg the register to load the value on top of the stack
     */
    public void emitPop(String reg)
    {
        emit("lw " + reg + " ($sp)   # pop a number off the stack");
        emit("addu $sp $sp 4");

        excessStackHeight--; //NEW
    }

    /**
     * gets the number of the if statement in order to ensure that
     * each label is unique
     *
     * @precondition ifnum >= 0
     * @postcondition ifnum incremented by one
     * @return the number of if statements
     */
    public int nextLabelID()
    {
        ifnum++;
        return ifnum;
    }

    /**
     * just like if statements, gets the number of while loops in order
     * to ensure that each label is unique
     *
     * @precondition whilenum >= 0
     * @postcondition whilenum incremented by one
     * @return the number of while statements
     */
    public int nextLabelID2()
    {
        whilenum++;
        return whilenum;
    }

    /**
     * remembers the procedure as the current procedure context
     *
     * @precondition proc valid procedure declaration
     * @postcondition currentProc set, excessStackHeight reset
     * @param proc the procedure
     */
    public void setProcedureContext(ProcedureDeclaration proc)
    {
        excessStackHeight = 0;
        currentProc = proc;
    }

    /**
     * clears the current procedure context
     *
     * @precondition currentProc is a valid procedure declaration
     * @postcondition remember null as current procedure context
     */
    public void clearProcedureContext()
    {
        currentProc = null;
    }

    /**
     * checks if a variable name is a local or global variable by
     * checking the procedure's (if any) parameters, name, and variables
     *
     * @precondition variable name is local or global
     * @postcondition name checked
     * @param varName the name of the variable
     * @return true if the variable name matches a local variable name; otherwise, returns false
     */
    public boolean isLocalVariable(String varName)
    {
        if (currentProc != null)
        {
            if (currentProc.getParameters().contains(varName)
                    || currentProc.getName().equals(varName))
            {
                return true;
            }
            for (int i = 0; i < currentProc.getVariables().size(); i++)
            {
                if (currentProc.getVariables().get(i).getName().equals(varName))
                {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * gets the location on the stack of the variable name where the order pushed is
     * the parameters, return value, then local variables
     *
     * @precondition variable name is the name of a local variable
     * for the procedure currently compiled
     * @postcondition place on stack found
     * @param localVarName the name of the local variable whose offset is determined
     * @return the offset
     */
    public int getOffset(String localVarName)
    {
        if (currentProc.getName().equals(localVarName))
        {
            return 4 * excessStackHeight;
        }
        else if (currentProc.getParameters().contains(localVarName))
        {
            return 4 * (currentProc.getParameters().size() - 1
                    - currentProc.getParameters().indexOf(localVarName))
                    + 4 * excessStackHeight + 4;
        }
        else
        {
            int index = 0;
            for (int i = 0; i < currentProc.getVariables().size(); i++)
            {
                if (currentProc.getVariables().get(i).getName().equals(localVarName))
                {
                    index = i;
                }
            }
            return 4 * excessStackHeight - 4 * (currentProc.getVariables().size() - index);
        }
    }
}