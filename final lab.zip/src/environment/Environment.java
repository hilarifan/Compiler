package environment;

import java.util.Map;
import java.util.HashMap;
import ast.Expression;
import ast.ProcedureDeclaration;

/**
 * Stores and remembers the values of the variables and procedures used to parse.
 *
 * Environment        - constructor
 * setVariable        - sets the variable to a value in an environment
 * getVariable        - gets the value of the variable in an environment
 * getProcedure       - gets the procedure in the global environment
 * setProcedure       - sets the procedure in the global environment
 * declareVariable    - declares the variable in the current environment
 *
 * @author Hilari Fan
 * @version 3/25/20
 *
 * Usage:
 * Stores all the variables and procedures in the global environment and
 * local variables to child environments for evaluating / executing the parsed text
 */
public class Environment
{
    private Map<String, Expression> variable;
    private Map<String, ProcedureDeclaration> procedure;
    private Environment parent;

    /**
     * constructor for the Environment that is used by the Evaluator
     *
     * @param parent the global environment or null if this environment is the global one
     */
    public Environment(Environment parent)
    {
        variable = new HashMap<String, Expression>();
        procedure = new HashMap<String, ProcedureDeclaration>();
        this.parent = parent;
    }

    /**
     * in a child environment, sets the variable name to the expression in the parent environment
     * if the variable has not been declared;
     * otherwise, sets the value of the variable in the local environment
     *
     * @precondition none
     * @postcondition a new value is associated with the key in the parent or local environment
     * @param var the name of the variable (key)
     * @param exp expression (value)
     */
    public void setVariable(String var, Expression exp)
    {
        if (parent != null && !variable.containsKey(var))
        {
            parent.setVariable(var, exp);
        }
        else
        {
            declareVariable(var, exp);
        }
    }

    /**
     * gets the Expression of a variable in the current environment if exists;
     * otherwise checks the parent environment
     *
     * @precondition the key, variable name, exists
     * @postcondition none
     * @param var the key
     * @return the value of the key
     */
    public Expression getVariable(String var)
    {
        if (variable.containsKey(var))
        {
            return variable.get(var);
        }
        else
        {
            return parent.getVariable(var);
        }
    }

    /**
     * gets the procedure declaration associated with its name in the global environment
     *
     * @precondition the procedure exists
     * @postcondition none
     * @param proc the name of the procedure
     * @return the procedure declaration
     */
    public ProcedureDeclaration getProcedure(String proc)
    {
        if (parent == null)
        {
            return procedure.get(proc);
        }
        else
        {
            return parent.getProcedure(proc);
        }
    }

    /**
     * sets the procedure name to a procedure declaration by
     * creating a new procedure in the global environment
     *
     * @precondition none
     * @postcondition a new procedure declaration is associated with the key
     * @param proc the name of the procedure (key)
     * @param dec the procedure declaration (value)
     */
    public void setProcedure(String proc, ProcedureDeclaration dec)
    {
        if (parent == null)
        {
            procedure.put(proc, dec);
        }
        else
        {
            parent.setProcedure(proc, dec);
        }
    }

    /**
     * declares a variable to a value in the current environment
     *
     * @precondition none
     * @postcondition a new value is associated with the key in the current environment
     * @param var the name of the variable (key)
     * @param exp expression (value)
     */
    public void declareVariable(String var, Expression exp)
    {
        variable.put(var, exp);
    }
}
