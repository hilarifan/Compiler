package environment;

import ast.*;
import ast.Number;
import emitter.Emitter;

/**
 * Class that evaluates / executes the parsed text
 *
 * exec     - an exec for the program and every statement + a general
 * eval     - an eval for every expression + a general
 *
 * @author Hilari Fan
 * @version 3/25/20
 *
 * Usage:
 * To execute the statements and evaluate the expressions of the parsed texts
 */
public class Evaluator
{
    /**
     * Constructor of the Evaluator
     */
    public Evaluator()
    {}

    /**
     * executes a program by first executing all the programs, if any, then executing the statement
     *
     * @precondition program has valid statement
     * @postcondition entire program executed
     * @param program the program
     * @param env the global environment in which procedures and global variables reside
     */
    public void exec(Program program, Environment env)
    {
        for (int i = 0; i < program.getDeclarations().size(); i++)
        {
            exec(program.getDeclarations().get(i), env);
        }

        exec(program.getStatement(), env);
    }

    /**
     * executes a statement by checking what type of statement it is
     * helper method for other exec methods
     *
     * @precondition stmt exists and valid
     * @postcondition stmt executed
     * @param stmt any statement
     * @param env the environment in which variables reside
     */
    public void exec(Statement stmt, Environment env)
    {
        if (stmt instanceof Writeln)
        {
            exec((Writeln) stmt, env);
        }
        else if (stmt instanceof Assignment)
        {
            exec((Assignment) stmt, env);
        }
        else if (stmt instanceof If)
        {
            exec((If) stmt, env);
        }
        else if (stmt instanceof While)
        {
            exec((While) stmt, env);
        }
        else
        {
            exec((Block) stmt, env);
        }
    }

    /**
     * executes a procedure declaration by putting the declaration into the
     * hashmap of the environment
     *
     * @precondition none
     * @postcondition procedure added to the hashmap of the global environment
     * @param dec the procedure declaration statement
     * @param env the environment in which global variables and procedures reside
     */
    public void exec(ProcedureDeclaration dec, Environment env)
    {
        env.setProcedure(dec.getName(), dec);
    }

    /**
     * evaluates the procedure call by extracting the procedure declaration from the global
     * environment and evaluating potential arguments
     *
     * @precondition procedure declaration of the procedure call exists and in global environment
     * @postcondition call evaluated, local variables if any created, global variables may change
     * @param call the procedure call
     * @param env the global environment in which variables reside
     * @return the value of the procedure call expression; otherwise, 0 as default
     */
    public int eval(ProcedureCall call, Environment env)
    {
        Environment child = new Environment(env);
        ProcedureDeclaration dec = env.getProcedure(call.getName());
        for (int i = 0; i < call.getArguments().size(); i++)
        {
            int num = eval(call.getArguments().get(i), env);
            child.declareVariable(dec.getParameters().get(i), new Number(num));
        }

        child.declareVariable(call.getName(), new Number(0));
        exec(dec.getStatement(), child);
        return eval(child.getVariable(call.getName()), child);
    }

    /**
     * executes a writeln statement by printing the evaluation of the statement
     *
     * @precondition stmt exists and valid
     * @postcondition stmt executed and value of expression printed
     * @param stmt the writeln statement
     * @param env the environment in which variables reside
     */
    public void exec(Writeln stmt, Environment env)
    {
        System.out.println(eval(stmt.getExpression(), env));
    }

    /**
     * executes a block by executing each statement in the block
     *
     * @precondition block exists and valid
     * @postcondition entire block executed
     * @param stmts the block
     * @param env the environment in which variables reside
     */
    public void exec(Block stmts, Environment env)
    {
        for (int i = 0; i < stmts.getStatements().size(); i++)
        {
            exec(stmts.getStatements().get(i), env);
        }
    }

    /**
     * executes an assignment statement and changes the variable value in the environment
     *
     * @precondition assignment exists and valid
     * @postcondition assignment evaluated and variable changed
     * @param assignment the assignment statement
     * @param env the environment in which variables reside
     */
    public void exec(Assignment assignment, Environment env)
    {
        int eval = eval(assignment.getExpression(), env);
        env.setVariable(assignment.getName(), new Number(eval));
    }

    /**
     * executes an if statement after checking if the condition is true
     *
     * @precondition if statement exists and valid
     * @postcondition statement in if statement executed if condition satisfied
     * @param ifstmt the if statement
     * @param env the environment in which variables reside
     */
    public void exec(If ifstmt, Environment env)
    {
        if (eval(ifstmt.getCondition(), env))
        {
            exec(ifstmt.getStatement(), env);
        }
    }

    /**
     * executes a while statement after checking if the condition is true,
     * and continues in a while loop
     *
     * @precondition while loop exists and valid
     * @postcondition statement in while loop executed until condition not satisfied
     * @param whilestmt the while loop
     * @param env the environment in which variables reside
     */
    public void exec(While whilestmt, Environment env)
    {
        while (eval(whilestmt.getCondition(), env))
        {
            exec(whilestmt.getStatement(), env);
        }
    }

    /**
     * evaluates the condition by extracting the expressions and relational operator
     *
     * @precondition relational operator in condition valid
     * @postcondition condition evaluated
     * @param cond the condition
     * @param env the environment in which variables reside
     * @return true if condition is true; otherwise, returns false
     */
    public boolean eval(Condition cond, Environment env)
    {
        boolean val;

        if (cond.getRelationalOperator().equals("or") || cond.getRelationalOperator().equals("and"))
        {
            boolean exp1 = eval((Condition) cond.getExpression1(), env);

            val = false;

            if (cond.getRelationalOperator().equals("or"))
            {
                if (exp1)
                {
                    val = true;
                }
                else
                {
                    boolean exp2 = eval((Condition) cond.getExpression2(), env);

                    if (exp2)
                    {
                        val = true;
                    }
                }
            }
            else
            {
                if (exp1)
                {
                    boolean exp2 = eval((Condition) cond.getExpression2(), env);

                    if (exp2)
                    {
                        val = true;
                    }
                }
            }
        }
        else
        {
            int exp1 = eval(cond.getExpression1(), env);
            int exp2 = eval(cond.getExpression2(), env);

            if (cond.getRelationalOperator().equals("="))
            {
                val = exp1 == exp2;
            }
            else if (cond.getRelationalOperator().equals("<>"))
            {
                val = exp1 != exp2;
            }
            else if (cond.getRelationalOperator().equals("<"))
            {
                val = exp1 < exp2;
            }
            else if (cond.getRelationalOperator().equals(">"))
            {
                val = exp1 > exp2;
            }
            else if (cond.getRelationalOperator().equals("<="))
            {
                val = exp1 <= exp2;
            }
            else
            {
                val = exp1 >= exp2;
            }
        }

        return val;
    }

    /**
     * evaluates the binary operation by extracting the expressions and binary operator
     *
     * @precondition binary operator in binop valid
     * @postcondition binop evaluated
     * @param binop the binary operation elements
     * @param env the environment in which variables reside
     * @return the value of the operation
     */
    public int eval(BinOp binop, Environment env)
    {
        int val;
        int exp1 = eval(binop.getExpression1(), env);
        int exp2 = eval(binop.getExpression2(), env);

        if (binop.getOperator().equals("+"))
        {
            val = exp1 + exp2;
        }
        else if (binop.getOperator().equals("-"))
        {
            val = exp1 - exp2;
        }
        else if (binop.getOperator().equals("*"))
        {
            val = exp1 * exp2;
        }
        else
        {
            val = exp1 / exp2;
        }
        return val;
    }

    /**
     * evaluates the number by extracting the integer
     *
     * @precondition num valid
     * @postcondition number evaluated
     * @param num the number
     * @param env the environment in which variables reside
     * @return the integer value of the number
     */
    public int eval(Number num, Environment env)
    {
        return num.getInt();
    }

    /**
     * evaluates the variable by extracting the expression from the
     * map of variables
     *
     * @precondition variable exists in map
     * @postcondition variable evaluated
     * @param var the variable
     * @param env the environment in which variables reside
     * @return the integer value of the variable
     */
    public int eval(Variable var, Environment env)
    {
        return eval(env.getVariable(var.getName()), env);
    }

    /**
     * evaluates an expression by checking what type of expression it is
     * helper method for other eval and exec methods
     *
     * @precondition expression valid
     * @postcondition expression evaluated
     * @param exp the expression to be evaluated
     * @param env env the environment in which variables reside
     * @return the integer value of the expression
     */
    public int eval(Expression exp, Environment env)
    {
        int val;

        if (exp instanceof BinOp)
        {
            val = eval((BinOp) exp, env);
        }
        else if (exp instanceof Number)
        {
            val = eval((Number) exp, env);
        }
        else if (exp instanceof Variable)
        {
            val = eval((Variable) exp, env);
        }
        else
        {
            val = eval((ProcedureCall) exp, env);
        }
        return val;
    }
}

