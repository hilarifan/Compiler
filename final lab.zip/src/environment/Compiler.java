package environment;
import ast.*;
import ast.Number;
import emitter.Emitter;

/**
 * Class that implements a simple compiler that reads a text program (like pascal)
 * and outputs a MIPS program
 *
 * compile  - a compile method for each statement and expression + a general of each
 *
 * @author Hilari Fan
 * @version 4/27/20
 *
 * Usage:
 * Compile a program
 */
public class Compiler
{
    /**
     * constructor of the Compiler
     */
    public Compiler()
    {}

    /**
     * compiles a program by taking in an output file name and creating
     * an Emitter to write a MIPS program
     *
     * @precondition file name valid
     * @postcondition all code is written to the file
     * @param p
     * @param file
     */
    public void compile(Program p, String file)
    {
        Emitter e = new Emitter(file);
        e.emit("# @author Hilari Fan"); // header
        e.emit("# @version 4/27/20");
        e.emit("");

        e.emit(".text");
        e.emit(".globl main");
        e.emit("");
        e.emit("main:");

        compile(p.getStatement(), e);

        e.emit("li $v0 10   # terminates the program");
        e.emit("syscall");
        e.emit("");

        for (int i = 0; i < p.getDeclarations().size(); i++)
        {
            compile(p.getDeclarations().get(i), e);
        }

        e.emit(".data");
        for (int i = 0; i < p.getVariables().size(); i++)
        {
            e.emit("var" + p.getVariables().get(i).getName() + ":");
            e.emit(".word 0");
        }

        e.emit("newline:");
        e.emit(".asciiz \"\\n\" ");

        e.close();
    }

    /**
     * compiles a statement by checking what type of statement it is
     * helper method for other compile methods
     *
     * @precondition stmt and emitter exists and valid
     * @postcondition stmt compiled
     * @param stmt any statement
     * @param e the emitter that writes code to a file
     */
    public void compile(Statement stmt, Emitter e)
    {
        if (stmt instanceof Writeln)
        {
            compile((Writeln) stmt, e);
            e.emit("");
        }
        else if (stmt instanceof Block)
        {
            compile((Block) stmt, e);
        }
        else if (stmt instanceof Assignment)
        {
            compile((Assignment) stmt, e);
            e.emit("");
        }
        else if (stmt instanceof If)
        {
            compile((If) stmt, e);
        }
        else
        {
            compile((While) stmt, e);
        }
    }

    /**
     * compiles a writeln statement by compiling the expression and printing the value
     *
     * @precondition writeln stmt and emitter exists and valid
     * @postcondition stmt compiled
     * @param w a  writeln statement
     * @param e the emitter that writes code to a file
     */
    public void compile(Writeln w, Emitter e)
    {
        compile(w.getExpression(), e);

        e.emit("move $a0 $v0   # prints a number");
        e.emit("li $v0 1");
        e.emit("syscall");
        e.emit("");

        e.emit("la $a0 newline   # prints a new line");
        e.emit("li $v0 4");
        e.emit("syscall");
    }

    /**
     * compiles a block by compiling each statement inside the block
     *
     * @precondition block stmt and emitter exists and valid
     * @postcondition stmt compiled
     * @param b a block statement
     * @param e the emitter that writes code to a file
     */
    public void compile(Block b, Emitter e)
    {
        for (int i = 0; i < b.getStatements().size(); i++)
        {
            compile(b.getStatements().get(i), e);
        }
    }

    /**
     * compiles an expression by checking what type of expression it is
     * helper method for other compile methods
     *
     * @precondition expression and emitter exists and valid
     * @postcondition expression compiled
     * @param exp any expression statement
     * @param e the emitter that writes code to a file
     */
    public void compile(Expression exp, Emitter e)
    {
        if (exp instanceof BinOp)
        {
            compile((BinOp) exp, e);
        }
        else if (exp instanceof Number)
        {
            compile((Number) exp, e);
        }
        else if (exp instanceof Variable)
        {
            compile((Variable) exp, e);
        }
        else
        {
            compile((ProcedureCall) exp, e);
        }
        e.emit("");
    }

    /**
     * compiles a number by loading the value into $v0
     *
     * @precondition num and emitter exists and valid
     * @postcondition expression compiled
     * @param num a number expression
     * @param e the emitter that writes code to a file
     */
    public void compile(Number num, Emitter e)
    {
        e.emit("li $v0 " + num.getInt());
    }

    /**
     * compiles a binop by compiling and pushing the value of the first expression onto a stack
     * and compiling the value of the second expression before the value of the first expression
     * gets popped off the stack and the binary operation completes
     *
     * @precondition binop and emitter exists and valid
     * @postcondition expression compiled
     * @param binop any binary operator expression
     * @param e the emitter that writes code to a file
     */
    public void compile(BinOp binop, Emitter e)
    {
        compile(binop.getExpression1(), e);
        e.emitPush("$v0");
        e.emit("");
        compile(binop.getExpression2(), e);

        e.emitPop("$t0");
        e.emit("");

        if (binop.getOperator().equals("+"))
        {
            e.emit("addu $v0 $t0 $v0   # add $t0 and $v0 and store in $v0");
        }
        else if (binop.getOperator().equals("-"))
        {
            e.emit("subu $v0 $t0 $v0   # subtract $v0 from $t0 and store in $v0");
        }
        else if (binop.getOperator().equals("*"))
        {
            e.emit("mult $t0 $v0   # multiply $t0 and $v0 and store in $v0");
            e.emit("mflo $v0");
        }
        else
        {
            e.emit("div $t0 $v0   # divde $t0 by $v0 and store in $v0");
            e.emit("mflo $v0");
        }
    }

    /**
     * compiles a variable by loading the value of the variable from the .data section into $v0
     * if it is a global variable; otherwise, loads the value of the local variable from the stack
     *
     * @precondition var and emitter exists and valid
     * @postcondition expression compiled
     * @param var any variable expression
     * @param e the emitter that writes code to a file
     */
    public void compile(Variable var, Emitter e)
    {
        if (e.isLocalVariable(var.getName()))
        {
            e.emit("lw $v0 " + e.getOffset(var.getName()) + "($sp)" +
                    "   # loads the local variable into $v0");
        }
        else
        {
            e.emit("la $t0 var" + var.getName() +
                    "   # loads the value of the global variable into $v0");
            e.emit("lw $v0 ($t0)");
        }
    }

    /**
     * compiles an assignment by compiling the expression and storing the value into the
     * .data for a global variable or stack for a local variable
     *
     * @precondition assignment and emitter exists and valid
     * @postcondition stmt compiled
     * @param a any assignment stmt
     * @param e the emitter that writes code to a file
     */
    public void compile(Assignment a, Emitter e)
    {
        compile(a.getExpression(), e);
        if (e.isLocalVariable(a.getName()))
        {
            e.emit("sw $v0 " + e.getOffset(a.getName()) + "($sp)" +
                    "   # stores the value of the local variable on the stack");
        }
        else
        {
            e.emit("sw $v0 var" + a.getName() + "   # assigns the value to the global variable");
        }
    }

    /**
     * compiles a condition by (like binop) compiling both expressions and pushing the
     * first one onto a stack and popping it off the stack to do the relational operation
     * the code for the comparison of the values is the opposite of the relational operator
     * to simplify the code (Ex: for x < y, emit bge...)
     *
     * @precondition condition and emitter exists and valid
     * @postcondition expression compiled
     * @param c any condition expression
     * @param label the label name if the condition is not met
     * @param e the emitter that writes code to a file
     */
    public void compile(Condition c, String label, Emitter e)
    {
        compile(c.getExpression1(), e);
        e.emitPush("$v0");
        e.emit("");
        compile(c.getExpression2(), e);

        e.emitPop("$t0");
        e.emit("");

        if (c.getRelationalOperator().equals("="))
        {
            e.emit("bne $t0 $v0 " + label + "   # if $t0 != $v0, execute label");
        }
        else if (c.getRelationalOperator().equals("<>"))
        {
            e.emit("beq $t0 $v0 " + label + "   # if $t0 = $v0, execute label");
        }
        else if (c.getRelationalOperator().equals("<"))
        {
            e.emit("bge $t0 $v0 " + label + "   # if $t0 >= $v0, execute label");
        }
        else if (c.getRelationalOperator().equals(">"))
        {
            e.emit("ble $t0 $v0 " + label + "   # if $t0 <= $v0, execute label");
        }
        else if (c.getRelationalOperator().equals("<="))
        {
            e.emit("bgt $t0 $v0 " + label + "   # if $t0 > $v0, execute label");
        }
        else
        {
            e.emit("blt $t0 $v0 " + label + "   # if $t0 < $v0, execute label");
        }
    }

    /**
     * compiles an if statement by compiling the condition then the statement and
     * creating a label if the condition is false
     * uses nextLabelID from Emitter to keep track of the label names
     *
     * @precondition if statement and emitter exists and valid
     * @postcondition stmt compiled
     * @param ifstmt an if statement
     * @param e the emitter that writes code to a file
     */
    public void compile(If ifstmt, Emitter e)
    {
        int num = e.nextLabelID();
        compile(ifstmt.getCondition(), "endif" + num, e);
        compile(ifstmt.getStatement(), e);

        e.emit("endif" + num + ":");
    }

    /**
     * compiles a while loop by (just like if) compiling the condition then the statement and
     * creating a label if the condition is false + emits j loop to loop over the code again
     * uses nextLabelID2 from Emitter to keep track of the while loop label names
     *
     * @precondition while statement and emitter exists and valid
     * @postcondition stmt compiled
     * @param w an while loop
     * @param e the emitter that writes code to a file
     */
    public void compile(While w, Emitter e)
    {
        int num = e.nextLabelID2();
        e.emit("loop" + num + ":");

        compile(w.getCondition(), "endloop" + num, e);
        compile(w.getStatement(), e);
        e.emit("j loop" + num);
        e.emit("");

        e.emit("endloop" + num + ":");
    }

    /**
     * compiles a procedure declaration by creating the subroutine label, pushing
     * a return value onto the stack, setting the procedure context, initiating all
     * local variables, and compiling the statement before getting the return value,
     * returning back from the subroutine, and clearing the procedure context
     *
     * @precondition procedure declaration and emitter exists and valid
     * @postcondition stmt compiled
     * @param dec the procedure declaration
     * @param e the emitter that writes code to a file
     */
    public void compile(ProcedureDeclaration dec, Emitter e)
    {
        e.emit("proc" + dec.getName() + ":");

        e.emit("li $v0 0");
        e.emit("");
        e.emitPush("$v0");
        e.emit("");

        e.setProcedureContext(dec);

        for (int i = 0; i < dec.getVariables().size(); i++)
        {
            e.emitPush("$v0");
            e.emit("");
        }

        compile(dec.getStatement(), e);

        e.emitPop("$v0");
        e.emit("");

        e.emit("jr $ra   # return from the subroutine");
        e.emit("");

        e.clearProcedureContext();
    }

    /**
     * compiles a procedure call by pushing the return address before compiling each argument
     * then calling the subroutine. After the call, the arguments get popped off the stack and
     * the return address gets popped
     *
     * @precondition procedure call (+ the procedure declaration of the call's name)
     * and emitter exists and valid
     * @postcondition expression compiled
     * @param call the procedure call
     * @param e the emitter that writes code to a file
     */
    public void compile(ProcedureCall call, Emitter e)
    {
        e.emitPush("$ra");
        e.emit("");

        for (int i = 0; i < call.getArguments().size(); i++)
        {
            compile(call.getArguments().get(i), e);
            e.emitPush("$v0");
            e.emit("");
        }

        e.emit("jal proc" + call.getName() + "   # call subroutine");
        e.emit("");

        for (int i = 0; i < call.getArguments().size(); i++)
        {
            e.emit("addu $sp $sp 4   # pops the arguments off the stack");
            e.emit("");
        }

        e.emitPop("$ra");
    }
}
