package parser;

import ast.*;
import ast.Number;
import environment.Evaluator;
import environment.Compiler;
import scanner.*;
import java.util.List;
import java.util.ArrayList;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashMap;

import environment.Environment;

/**
 * This is a file for a top-down recursive descent parser that can parse certain statements
 * without executing / evaluating them.
 *
 * Parser              - constructor from a given scanner
 * eat                 - advances to the next token of the scanner
 * parseNumber         - turns the current token into an integer
 * parseFactor         - gets the Expression of any factor
 * parseArgs           - gets the list of expressions of the arguments
 * parseTerm           - gets the Expression of any term
 * parseExpression     - gets the Expression
 * parseStatement      - gets the Statement
 * parseCondition      - gets the Condition
 * changeRelop         - gets the opposite relational operator (not)
 * parseAnd            - gets part of the condition (and)
 * parseOr             - gets part of the condition (or)
 * parseRelop          - gets the relational operator
 * parseStatements     - gets the Block of the statements
 * parseProgram        - gets the Program
 * parseVariable       - gets the list of variable names
 * parseProcedure      - gets the list of procedures
 * parseParms          - gets the list of strings of the parameters
 *
 * @author Hilari Fan
 * @version 3/9/20
 *
 * Usage:
 * parses the statements by using the specified grammar described in this class
 *
 */
public class Parser
{
    private Scanner scan;
    private String currentToken;
    private Environment env;

    /**
     * constructor for parser that uses a scanner for the input
     *
     * Usage:
     * FileInputStream inStream = new FileInputStream(new File(<file name>)_;
     * scanner.Scanner lex = new scanner.Scanner(inStream);
     * Parser par = new Parser(lex);
     *
     * @param scan the scanner to use
     */
    public Parser(Scanner scan)
    {
        this.scan = scan;
        try
        {
            currentToken = this.scan.nextToken();
            env = new Environment(null); // creates the global environment
        }
        catch (ScanErrorException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * checks if the string taken in is the same as the current token
     * advances and stores the next token if they match; otherwise, throws an exception
     *
     * @precondition scanner has a next token
     * @postcondition currentToken is updated
     *
     * Usage:
     * eat("(");
     *
     * @param expected the string that the current token should match
     */
    private void eat(String expected)
    {
        if (expected.equals(currentToken))
        {
            try
            {
                currentToken = scan.nextToken();
            }
            catch (ScanErrorException e)
            {
                e.printStackTrace();
            }
        }
        else
        {
            throw new IllegalArgumentException("expected " + expected + " & found " + currentToken);
        }
    }

    /**
     * parses the current token and gets that Number
     *
     * Usage:
     * return parseNumber(); (in parse factor)
     *
     * @precondition current token is an integer
     * @postcondition number token has been eaten
     * @return the Number of the integer
     */
    private Number parseNumber()
    {
        int num = Integer.parseInt(currentToken);
        eat(currentToken);
        return new Number(num);
    }

    /**
     * parses the factor, which refers to any expression that may be multiplied or divided
     * factor -> (expr) | -factor | num | id(maybeargs) | id
     *
     * Usage:
     * term = new BinOp("*", term, parseFactor()); (in parse term)
     *
     * @precondition current token is part of or is a factor
     * @postcondition current token eaten (with all tokens in the factor)
     * @return Expression of the factor
     */
    public Expression parseFactor()
    {
        if (currentToken.equals("("))
        {
            eat("(");
            Expression exp = parseExpression();
            eat(")");
            return exp;
        }
        else if (currentToken.equals("-"))
        {
            eat("-");
            return new BinOp("-",new Number(0), parseFactor());
        }
        else if (scan.isLetter(currentToken.charAt(0)))
        {
            String key = currentToken;
            eat(currentToken);

            if (currentToken.equals("(")) // id is a procedure
            {
                eat("(");
                ArrayList<Expression> args = new ArrayList<Expression>();
                args.addAll(parseArgs());
                eat(")");
                return new ProcedureCall(key, args);
            }
            else
            {
                return new Variable(key);
            }
        }
        else
        {
            return parseNumber();
        }
    }

    /**
     * parses the arguments of a procedure call defined by
     * maybeargs -> args | e
     * args -> args, expr | expr
     *
     * Usage:
     * args.addAll(parseArgs()); (in parse factor)
     *
     * @precondition current token is part of an argument or ")"
     * @postcondition current token eaten along with all arguments
     * @return a list of the expression of each argument
     */
    public ArrayList<Expression> parseArgs()
    {
        ArrayList<Expression> args = new ArrayList<Expression>();
        if (!currentToken.equals(")"))
        {
            args.add(parseExpression());

            while (currentToken.equals(","))
            {
                eat(",");
                args.add(parseExpression());
            }
        }
        return args;
    }

    /**
     * parses the term, which refers to any expression that may be added or subtracted
     * term -> term * factor | term / factor | factor
     *
     * Usage:
     * exp = new BinOp("+", exp, parseTerm()); (in parse expression)
     *
     * @precondition current token is part of or is a term
     * @postcondition current token eaten (with all tokens in the term)
     * @return Expression of the term
     */
    public Expression parseTerm()
    {
        Expression term = parseFactor();

        while (currentToken.equals("*") || currentToken.equals("/"))
        {
            if (currentToken.equals("*"))
            {
                eat("*");
                term = new BinOp("*", term, parseFactor());
            }
            else
            {
                eat("/");
                term = new BinOp("/", term, parseFactor());
            }
        }

        return term;
    }

    /**
     * parses any expression (which is what is inside writeln(...) or id:= ...)
     * expression -> expression + term | expression - term | term
     *
     * Usage:
     * variable.put(id, parseExpression());
     *
     * @precondition current token is part of or is a expression
     * @postcondition current token eaten (with all tokens in the expression)
     * @return an Expression
     */
    public Expression parseExpression()
    {
        Expression exp = parseTerm();

        while (currentToken.equals("+") || currentToken.equals("-"))
        {
            if (currentToken.equals("+"))
            {
                eat("+");
                exp = new BinOp("+", exp, parseTerm());
            }
            else
            {
                eat("-");
                exp = new BinOp("-", exp, parseTerm());
            }
        }

        return exp;
    }

    /**
     * parse a statement defined as
     * stmt -> WRITELN(expr); | BEGIN stmts END; | id:= expr |
     * IF cond THEN stmt | WHILE cond DO stmt;
     *
     * Usage:
     * stmts.add(parseStatement()); (in parse statements)
     *
     * @precondition current token is WRITELN, BEGIN, or, id
     * @postcondition current token eaten (with all tokens in the statement)
     * @return the Statement
     */
    public Statement parseStatement()
    {
        if (currentToken.equals("WRITELN"))
        {
            eat("WRITELN");
            eat("(");
            Expression exp = parseExpression();
            eat(")");
            eat(";");
            return new Writeln(exp);
        }
        else if (currentToken.equals("BEGIN"))
        {
            eat("BEGIN");
            Block stmts = parseStatements();
            eat("END");
            eat(";");
            return stmts;
        }
        else if (currentToken.equals("IF"))
        {
            eat("IF");
            Condition cond = parseOr();
            eat("THEN");
            return new If(cond, parseStatement());
        }
        else if (currentToken.equals("WHILE"))
        {
            eat("WHILE");
            Condition cond = parseCondition();
            eat("DO");
            return new While(cond, parseStatement());
        }
        else
        {
            String id = currentToken;
            eat(id);
            eat(":=");
            Expression exp = parseExpression();
            env.setVariable(id, exp);
            eat(";");
            return new Assignment(id, exp);
        }
    }

    /**
     * parse a condition defined as
     * condition -> (! | ep) expr relop expr | (condition or)
     *
     * Usage:
     * Condition c = parseCondition(); (in parse and)
     *
     * @precondition current token is an expression, (, or not
     * @postcondition current token eaten (with all tokens in the condition(s))
     * @return the Condition
     */
    public Condition parseCondition()
    {
        if (currentToken.equals("("))
        {
            eat("(");
            Condition c = parseOr();
            eat(")");
            return c;
        }
        else if (currentToken.equals("not")) // for DeMorgan's case
        {
            eat("not");

            if (currentToken.equals("("))
            {
                eat("(");
                Condition c = parseOr();
                eat(")");

                // to make !(A || B) into !A && !B OR !(A && B) INTO !A || !B
                Condition c1 = (Condition) c.getExpression1();
                Condition c2 = (Condition) c.getExpression2();
                String op = c.getRelationalOperator();

                if (op.equals("or"))
                {
                    op = "and";
                }
                else
                {
                    op = "or";
                }

                String relop1 = changeRelop(c1.getRelationalOperator());
                String relop2 = changeRelop(c2.getRelationalOperator());

                return new Condition(op,
                        new Condition(relop1, c1.getExpression1(), c1.getExpression2()),
                        new Condition(relop2, c2.getExpression1(), c2.getExpression2()));
            }

            Expression exp = parseExpression();

            String relop = parseRelop();
            relop = changeRelop(relop);

            return new Condition(relop, exp, parseExpression());
        }
        else
        {
            Expression exp = parseExpression();
            return new Condition(parseRelop(), exp, parseExpression());
        }
    }

    /**
     * helper method for parseCondition that gets the not of the relational operator
     *
     * @precondition relop valid
     * @postcondition opposite relop obtained
     * @param relop the relational operator
     * @return relop
     */
    public String changeRelop(String relop)
    {
        if (relop.equals("="))
        {
            relop = "<>";
        }
        else if (relop.equals("<>"))
        {
            relop = "=";
        }
        else if (relop.equals("<"))
        {
            relop = ">=";
        }
        else if (relop.equals(">"))
        {
            relop = "<=";
        }
        else if (relop.equals("<="))
        {
            relop = ">";
        }
        else
        {
            relop = "<";
        }

        return relop;
    }

    /**
     * parse the and of a condition defined as
     * conditionand -> conditionand && condition | condition
     *
     * Usage:
     * Condition c = parseCondition(); (in parse and)
     *
     * @precondition current token is a part of a condition
     * @postcondition current token eaten (with all tokens in the condition(s))
     * @return the Condition
     */
    public Condition parseAnd()
    {
        Condition c = parseCondition();

        while (currentToken.equals("and"))
        {
            eat("and");
            c = new Condition("and", c, parseCondition());
        }

        return c;
    }

    /**
     * parse the or of a condition defined as
     * conditionor -> conditionor || conditionand | conditionand
     *
     * Usage:
     * Condition cond = parseOr(); (in parse statement)
     *
     * @precondition current token is part of a condition
     * @postcondition current token eaten (with all tokens in the condition(s))
     * @return the Condition
     */
    public Condition parseOr()
    {
        Condition c = parseAnd();

        while (currentToken.equals("or"))
        {
            eat("or");
            c = new Condition("or", c, parseAnd());
        }

        return c;
    }

    /**
     * parses a relational operator defined as
     * relop -> = | <> | < | > | <= | >=
     *
     * Usage:
     * new Condition(parseRelop(), exp, parseExpression()); (in parse condition)
     *
     * @precondition current token is a relop
     * @postcondition current token eaten
     * @return a String of the relational operator
     */
    public String parseRelop()
    {
        String relop = currentToken;
        eat(currentToken);
        return relop;
    }

    /**
     * parses the statements
     * stmts -> stmts stmt | epsilon
     *
     * Usage:
     * p.parseStatements(); (in main)
     *
     * @precondition current token is the first token of a statement
     * WRITELN, BEGIN, id, if, while
     * @postcondition all tokens in the block eaten
     * @return a Block of the statements
     */
    public Block parseStatements()
    {
        List<Statement> stmts = new ArrayList<Statement>();
        while (scan.hasNext() && !currentToken.equals("END"))
        {
            stmts.add(parseStatement());
        }

        return new Block(stmts);
    }

    /**
     * parses the program defined by
     * program -> PROCEDURE id(maybeparms); stmt program | stmt
     *
     * Usage:
     * Program pr = p.parseProgram(); (in main)
     *
     * @precondition current token is VAR, PROCEDURE, or the first token of a statement
     * @postcondition all tokens eaten
     * @return the program
     */
    public Program parseProgram()
    {
        return new Program(parseVariable(), parseProcedure(), parseStatement());
    }

    /**
     * parses the variables in the text (global for the program and local for the procedures)
     *
     * Usage:
     * return new Program(parseVariable(), parseProcedure(), parseStatement()); (in parse program)
     *
     * @precondition current token is VAR, PROCEDURE, or the first token of a statement
     * @postcondition all variable names, if any, eaten
     * @return the list of variables
     */
    public ArrayList<Variable> parseVariable()
    {
        ArrayList<Variable> var = new ArrayList<Variable>();

        while (currentToken.equals("VAR"))
        {
            eat("VAR");
            var.add(new Variable(currentToken));
            eat(currentToken);

            while (currentToken.equals(","))
            {
                eat(",");
                var.add(new Variable(currentToken));
                eat(currentToken);
            }

            eat(";");
        }

        return var;
    }

    /**
     * parses the procedures in the code
     *
     * Usage:
     * return new Program(parseVariable(), parseProcedure(), parseStatement()); (in parse program)
     *
     * @precondition current token is PROCEDURE or the first token of a statement
     * @postcondition all procedure, if any, eaten
     * @return the list of procedures
     */
    public ArrayList<ProcedureDeclaration> parseProcedure()
    {
        ArrayList<ProcedureDeclaration> dec = new ArrayList<ProcedureDeclaration>();

        while (currentToken.equals("PROCEDURE"))
        {
            eat("PROCEDURE");
            String id = currentToken;
            eat(id);
            eat("(");

            ArrayList<String> parms = new ArrayList<String>();
            parms.addAll(parseParms());

            eat(")");
            eat(";");

            dec.add(new ProcedureDeclaration(id, parseVariable(), parseStatement(), parms));
        }

        return dec;
    }

    /**
     * parses the parameters of the procedure defined by
     * maybeparms -> parms | e
     * parms -> parms, id | id
     *
     * Usage:
     * parms.addAll(parseParms()); (in parse program)
     *
     * @precondition current token is a parameter or ")"
     * @postcondition current token eaten along with all parameters
     * @return a list of the string of each parameter
     */
    public ArrayList<String> parseParms()
    {
        ArrayList<String> parms = new ArrayList<String>();
        if (!currentToken.equals(")"))
        {
            parms.add(currentToken);
            eat(currentToken);

            while (currentToken.equals(","))
            {
                eat(",");
                parms.add(currentToken);
                eat(currentToken);
            }
        }
        return parms;
    }

    /**
     * tests the functionality of the parser using ParserTest
     * @param args the argument
     */
    public static void main(String[] args)
    {
        File file = new File("finalTest.txt");
        try
        {
            FileInputStream inStream = new FileInputStream(file);
            Scanner s = new Scanner(inStream);
            Parser p = new Parser(s);
            Program pr = p.parseProgram();
            Environment env = new Environment(null);
            Evaluator e = new Evaluator();
            e.exec(pr, env);
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
    }
}
